.onAttach = function(libname, pkgname){
packageStartupMessage(
"\n
****************************** IMPORTANT ************************************
Package DESK:
  - is released for EDUCATIONAL PURPOSES, accompanying L. v.Auer,
    Oekonometrie - Eine Einfuehrung, Springer-Gabler)
  - comes with NO WARRANTY whatsoever

Please report bugs and errors to: sohoffmann@web.de (THANKS!)
*****************************************************************************
\n"
)
}