# desk
didactic econometrics starter kit
---------------------------------

This package includes tools and procedures that may be helpful for learning and teaching undergraduate econometrics.
Its main purpose is to help students to get a quick introduction into basic econometrics using R. Basically this package 
can be used with any undergraduate econometrics textbook, however, it was written to accompany the german textbook

     "Ökonometrie - Das R-Arbeitsbuch", by L. v. Auer and S. Hoffmann, Springer Verlag, 2016.

Note that the usage of this package comes with no warranty whatsoever.