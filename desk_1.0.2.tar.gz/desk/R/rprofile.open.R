rprofile.open = function(){
  file.show(paste(R.home(component = "etc"),"/Rprofile.site", sep =""))
}